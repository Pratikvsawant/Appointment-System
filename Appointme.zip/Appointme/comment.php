<?php 

include 'config.php';

error_reporting(0); // For not showing any error

if (isset($_POST['submit'])) { // Check press or not Post Comment Button
	$name = $_POST['name']; // Get Name from form
	$email = $_POST['email']; // Get Email from form
	$comment = $_POST['comment']; // Get Comment from form

	$sql = "INSERT INTO comments (name, email, comment)
			VALUES ('$name', '$email', '$comment')";
	$result = mysqli_query($conn, $sql);
	if ($result) {
		echo "<script>alert('Comment added successfully.')</script>";
	} else {
		echo "<script>alert('Comment does not add.')</script>";
	}
}

?>
<!DOCTYPE html>    
<html>    
<head>    
<meta name="viewport" content="width=device-width, initial-scale=1">    
<style>    
*{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Montserrat',sans-serif;
}
nav{
  background: #151515;
  padding: 5px 40px;
}
nav ul{
  list-style: none;
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: center;
}
nav ul li{
  padding: 15px 0;
  cursor: pointer;
}
nav ul li.items{
  position: relative;
  width: auto;
  margin: 0 16px;
  text-align: center;
  order: 3;
}
nav ul li.items:after{
  position: absolute;
  content: '';
  left: 0;
  bottom: 5px;
  height: 2px;
  width: 100%;
  background: #33ffff;
  opacity: 0;
  transition: all 0.2s linear;
}
nav ul li.items:hover:after{
  opacity: 1;
  bottom: 8px;
}
nav ul li.logo{
  flex: 1;
  color: white;
  font-size: 30px;
  font-weight: 600;
  cursor: default;
  user-select: none;
  font-family: 'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;

}
nav ul li a{
  color: white;
  font-size: 21px;
  text-decoration: none;
  transition: .4s;
}
nav ul li:hover a{
  color: cyan;
}
nav ul li i{
  font-size: 23px;
}
nav ul li.btn{
  display: none;
}
nav ul li.btn.hide i:before{
  content: '\f00d';
}
@media all and (max-width: 900px){
  nav{
    padding: 5px 30px;
  }
  nav ul li.items{
    width: 100%;
    display: none;
  }
  nav ul li.items.show{
    display: block;
  }
  nav ul li.btn{
    display: block;
  }
  nav ul li.items:hover{
    border-radius: 5px;
    box-shadow: inset 0 0 5px #33ffff,
                inset 0 0 10px #66ffff;
  }
  nav ul li.items:hover:after{
    opacity: 0;
  }
}

    
input[type=text], select, textarea {    
  width: 100%;    
  padding: 12px;    
  border: 1px solid rgb(70, 68, 68);    
  border-radius: 4px;    
  resize: vertical;    
}    
input[type=email], select, textarea {    
  width: 100%;    
  padding: 12px;    
  border: 1px solid rgb(70, 68, 68);    
  border-radius: 4px;    
  resize: vertical;    
}    
    
label {    
  padding: 12px 12px 12px 0;    
  display: inline-block;    
}    
    
input[type=submit] {    
  background-color: rgb(37, 116, 161);    
  color: white;    
  padding: 12px 20px;    
  border: none;    
  border-radius: 4px;    
  cursor: pointer;    
  float: right;    
}    
    
input[type=submit]:hover {    
  background-color: #45a049;    
}    
    
.container {    
  border-radius: 5px;    
  background-color: #f2f2f2;    
  padding: 20px;    
}    
    
.col-25 {    
  float: left;    
  width: 25%;    
  margin-top: 6px;    
}    
    
.col-75 {    
  float: left;    
  width: 75%;    
  margin-top: 6px;    
}    
    
/* Clear floats after the columns */    
.row:after {    
  content: "";    
  display: table;    
  clear: both;    
}    
 .prev-comments {
    margin-top: 30px;
    background-color: #5b5ee7;
}

.prev-comments .single-item {
    background:rgb(121, 178, 224)
    box-shadow: 0 5px 10px rgba(0,0,0,0.2);
    padding: 10px 10px;
    text-align: left;
    margin-bottom: 15px;
    border:red;
}

 .prev-comments .single-item h4 {
    font-size: 1.3rem;
    font-weight: 800;
    color: #111;
}

.prev-comments .single-item a {
    font-size: 1rem;
    color: #111;
    text-decoration:dotted;
    display: inline-block;
}

.prev-comments .single-item p {
    font-size: 1rem;
    color: #111;
}
hr.rounded {
  border-top: 8px solid rgb(7, 7, 41);
  border-radius: 5px;
  
}
</style>    
</head>    
<body>    
	<nav>
		<ul>
		   <li class="logo">AppointMe</li>
		   <li class="items"><a href="home.php">Home</a></li>
		   <li class="items"><a href="about.php">About</a></li>
		   <li class="items"><a href="contact.php">Contact</a></li>
		   <li class="items"><a href="appointwith.php">Appoint With</a></li>
		   <li class="items"><a href="feedback.php">Commment</a></li>
		   <li class="btn"><a href="#"><i class="fas fa-bars"></i></a></li>
		</ul>
	 </nav>
<h2 style="text-align:center; font-family:'Times New Roman', Times, serif;font-size:35px">! Leave Us a Comment !</h2>    
<div class="container">    
  <form method="POST" class="form">    
    <div class="row">    
      <div class="col-25">    
        <label for="name"> Name</label>    
      </div>    
      <div class="col-75">    
        <input type="text" id="name" name="name" placeholder="Your name.." required>    
      </div>    
    </div>    
    <div class="row">    
        <div class="col-25">    
          <label for="email">Email</label>    
        </div>    
        <div class="col-75">    
          <input type="email" id="email" name="email" placeholder="Your mail id.." required>    
        </div>    
      </div>    
    <div class="row">    
      <div class="col-25">    
        <label for="comment">Comment</label>    
      </div>    
      <div class="col-75">    
        <textarea id="comment" name="comment" placeholder="Write something.." style="height:200px"></textarea>    
      </div>    
    </div>    
    <div class="row">    
      <button name="submit" class="btn" style=" background-color: rgb(37, 116, 161);color: white; padding: 12px 20px; border: none; border-radius: 4px;cursor: pointer;float: right; ">Post Comment</button> 
    </div>    
  </form>    
</div>   
<hr class="rounded">
<div class="prev-comments"> 
<?php 
			
			$sql = "SELECT * FROM comments";
			$result = mysqli_query($conn, $sql);
			if (mysqli_num_rows($result) > 0) {
				while ($row = mysqli_fetch_assoc($result)) {

			?>
			<div class="single-item">
				<h4><?php echo $row['name']; ?></h4>
				<a href="mailto:<?php echo $row['email']; ?>"><?php echo $row['email']; ?></a>
				<p><?php echo $row['comment']; ?></p>
			</div>
			<?php

				}
			}
			
			?>

    </div>
    <script>
      $(document).ready(function(){
        $('.btn').click(function(){
          $('.items').toggleClass("show");
          $('ul li').toggleClass("hide");
        });
      });
      </script>
</body>    
</html>    