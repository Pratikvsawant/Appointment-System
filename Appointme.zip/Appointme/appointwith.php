<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Appointment System</title>
	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Allura&display=swap" rel="stylesheet">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/css/bootstrap.min.css" rel="stylesheet">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" rel="stylesheet">
	<style>
         @import url('https://fonts.googleapis.com/css?family=Montserrat:400,500,600,700&display=swap');
*{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Montserrat',sans-serif;
}
nav{
  background: #151515;
  padding: 5px 40px;
}
nav ul{
  list-style: none;
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: center;
}
nav ul li{
  padding: 15px 0;
  cursor: pointer;
}
nav ul li.items{
  position: relative;
  width: auto;
  margin: 0 16px;
  text-align: center;
  order: 3;
}
nav ul li.items:after{
  position: absolute;
  content: '';
  left: 0;
  bottom: 5px;
  height: 2px;
  width: 100%;
  background: #33ffff;
  opacity: 0;
  transition: all 0.2s linear;
}
nav ul li.items:hover:after{
  opacity: 1;
  bottom: 8px;
}
nav ul li.logo{
  flex: 1;
  color: white;
  font-size: 30px;
  font-weight: 600;
  cursor: default;
  user-select: none;
  font-family: 'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;

}
nav ul li a{
  color: white;
  font-size: 21px;
  text-decoration: none;
  transition: .4s;
}
nav ul li:hover a{
  color: cyan;
}
nav ul li i{
  font-size: 23px;
}
nav ul li.btn{
  display: none;
}
nav ul li.btn.hide i:before{
  content: '\f00d';
}
@media all and (max-width: 900px){
  nav{
    padding: 5px 30px;
  }
  nav ul li.items{
    width: 100%;
    display: none;
  }
  nav ul li.items.show{
    display: block;
  }
  nav ul li.btn{
    display: block;
  }
  nav ul li.items:hover{
    border-radius: 5px;
    box-shadow: inset 0 0 5px #33ffff,
                inset 0 0 10px #66ffff;
  }
  nav ul li.items:hover:after{
    opacity: 0;
  }
}
        body {
	font-family: 'Montserrat', sans-serif;
}
#team {
	padding: 30px 0;
}
.sec-heading h6 {
	font-family:Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
	font-size: 65px;
    color: #04035c;
    font-size: bold;
    border: lightblue;
}
.single-box {
	border: 1px solid #ddd;
	border-radius: 20px;
	overflow: hidden;
	background-color: #fff
}
.info-area {
	padding: 0 20px 45px;
}
.img-area {
	overflow: hidden;
	padding: 15px 0 15px;
}
.img-area img {
	margin: 0 auto;
	-webkit-transition: all 0.5s ease;
	transition: all 0.5s ease;
	max-width: 200px
}
.single-box:hover img {
	-webkit-transform: scale(1.1);
	transform: scale(1.1);
}
.info-area i {
	display: inline-block;
	color: #ffb400;
	margin: 0 4px;
}
.info-area h4 {
	font-weight: 600
}
.info-area h5 {
	color: #3b04db;
	margin: 10px 0 0;
	font-weight: 600
}
.info-area a {
	display: inline-block;
	margin: 25px 0 0;
	background-color: darkblue;
	color: #fff;
	padding: 10px 35px;
	border-radius: 4px;
}
.team-slider .owl-dots {
	position: absolute;
	left: 0;
	right: 0;
	bottom: -60px;
	text-align: center;
	width: 100%;
}
.team-slider button.owl-dot {
	width: 16px;
	height: 16px;
	display: inline-block;
	margin: 0 6px;
	text-align: center;
	border-radius: 50%;
	background-color: #262626;
}
.team-slider .owl-dot.active {
	background-color:black;
}
.move-animation {
	position: relative;
	-webkit-animation: move-animation 2s ease-in-out infinite;
	animation: move-animation 2s ease-in-out infinite;
}
 @-webkit-keyframes move-animation {
	0% {
		top: 3px;
	}
	50% {
		top: -3px;
	}
	100% {
		top: 3px;
	}
}
hr.rounded {
  border-top: 8px solid rgb(7, 7, 41);
  border-radius: 5px;
  
}
*, *::before, *::after {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

html {
    font-family: sans-serif;
    font-size: 10px;
}


.container h2 {
    letter-spacing: 1px;
    font-size: 50px;
    color: #6968aa;
    border: 2px dashed #0181a0;
    padding: 10px;
    text-transform: uppercase;
    border-radius: 10px;
    display: inline-block;
    cursor: pointer;
    text-align: center;
    margin-top: 90px;
    margin-left: 375px;
}

.blog-post {
    width: 100%;
    max-width: 98rem;
    padding: 5rem;
    background-color: #dbf4ff21;
    box-shadow: 0 1.4rem 8rem rgba(0, 0, 0, 0.2);
    display: flex;
    align-items: center;
    border-radius: .8rem;
    margin: 10px;
}

.blog-post_img {
    min-width: 35rem;
    max-width: 35rem;
    height: 30rem;
    transform: translateX(-8rem);
    position: relative;
}

.blog-post_img img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: .8rem;
    display: block;
}

.blog-post_img img::before {
    content: '';
    width: 100%;
    height: 100%;
    position: absolute;
    top: 0;
    left: 0;
    box-shadow: .5rem .5rem 3rem 1px rgba(0, 0, 0, 0.5);
    border-radius: .8rem;
}

.blog-post_date span {
    display: block;
    color: #00000080;
    font-size: 1.6rem;
    font-weight: 600;
    margin: .5rem 0;
}

.blog-post_title {
    font-size: 2.5rem;
    margin: 1.5rem 0 2rem;
    text-transform: uppercase;
    color: #4facfe;
}

.blog-post_text {
    margin-bottom: 3rem;
    font-size: 1.4rem;
    color: #000000b3;
}

.blog-post_cta {
    display: inline-block;
    padding: 1.5rem 3rem;
    letter-spacing: 1px;
    text-transform: uppercase;
    font-size: 1.2rem;
    color: #fff;
    text-decoration: none;
    border-radius: .8rem;
    background: linear-gradient(to right, #c945cf 0%, #04a6bd 100%);
}

.blog-post_cta:hover {
    background: linear-gradient(to right, #04a6bd 0%, #c945cf 100%);
}

@media screen and (max-width: 1068px) {
    .blog-post {
        max-width: 80rem;
    }
    .blog-post_img {
        min-width: 30rem;
        max-width: 30rem;
    }
    .container h2 {
        margin-top: 120px;
        margin-left: 275px;
    }
}

@media screen and (max-width: 868px) {
    .blog-post {
        max-width: 70rem;
    }
    .container h2 {
        margin-top: 20px;
        margin-left: 142px;
    }
}

@media screen and (max-width: 768px) {
    .blog-post {
        padding: 2.5rem;
        flex-direction: column;
    }
    .blog-post_img {
        min-width: 100%;
        max-width: 100%;
        transform: translate(0, -1rem);
    }
    .container {
        margin-top: auto;
    }
}

@media screen and (max-width: 823px) {
    .container h2 {
        margin-top: 35px;
        margin-left: 142px;
    }
}

footer{
    position: relative;
    bottom: 0;
    left: 0;
    right: 0;
    background: #111;
    height: auto;
    width: 100vw;

    padding-top: 0;
    color: #fff;
}
.footer-content{
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    text-align: center;
}
.footer-content h3{
    font-size: 2.1rem;
    font-weight: 500;
    text-transform: capitalize;
    line-height: 3rem;
    font-family: 'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;

}
.footer-content p{
    max-width: 500px;
    margin: 10px auto;
    line-height: 28px;
    font-size: 14px;
    color: #cacdd2;
}
.socials{
    list-style: none;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 1rem 0 3rem 0;
}
.socials li{
    margin: 0 10px;
}
.socials a{
    text-decoration: none;
    color: #fff;
    border: 1.1px solid white;
    padding: 5px;

    border-radius: 50%;

}
.socials a i{
    font-size: 1.1rem;
    width: 20px;


    transition: color .4s ease;

}
.socials a:hover i{
    color: aqua;
}

.footer-bottom{
    background: #000;
    width: 100vw;
    padding: 20px;
padding-bottom: 40px;
    text-align: center;
}
.footer-bottom p{
float: left;
    font-size: 14px;
    word-spacing: 2px;
    text-transform: capitalize;
}
.footer-bottom p a{
  color:#44bae8;
  font-size: 16px;
  text-decoration: none;
}
.footer-bottom span{
    text-transform: uppercase;
    opacity: .4;
    font-weight: 200;
}
.footer-menu{
  float: right;

}
.footer-menu ul{
  display: flex;
}
.footer-menu ul li{
padding-right: 10px;
display: block;
}
.footer-menu ul li a{
  color: #cfd2d6;
  text-decoration: none;
}
.footer-menu ul li a:hover{
  color: #27bcda;
}

@media (max-width:500px) {
.footer-menu ul{
  display: flex;
  margin-top: 10px;
  margin-bottom: 20px;
}
}
    </style>
</head>
<body>
    <nav>
        <ul>
           <li class="logo">AppointMe</li>
           <li class="items"><a href="home.php">Home</a></li>
           <li class="items"><a href="about.php">About</a></li>
           <li class="items"><a href="contact.php">Contact</a></li>
           <li class="items"><a href="appointwith.php">Appoint With</a></li>
           <li class="items"><a href="comment.php">Comment</a></li>
           <li class="btn"><a href="#"><i class="fas fa-bars"></i></a></li>
        </ul>
     </nav>
	<section id="team">
		<div class="container1">
			<div class="row">
				<div class="col-lg-8 offset-lg-2 col-md-10 offset-md-1">
					<div class="sec-heading text-center">
						<h6>Experts</h6>
					</div>
				</div>
			</div>
		</div>
		<div class="testimonial-box">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="team-slider owl-carousel">
							<div class="single-box text-center">
								<div class="img-area"><img alt="" class="img-fluid move-animation" src="pavan1.jpg"></div>
								<div class="info-area">
									<h4>Pavan Raw</h4>
									<p>ANDROID DEVELOPMENT.</p><a href="pavan.php">Appoint</a>
								</div>
							</div>
							<div class="single-box text-center">
								<div class="img-area"><img alt="" class="img-fluid move-animation" src="rushikesh1.jpg"></div>
								<div class="info-area">
									<h4>Rushikesh Katkar</h4>
									<p>BLOCKCHAIN TECHNOLOGY</p><a href="html.php">Appoint</a>
								</div>
							</div>
							<div class="single-box text-center">
								<div class="img-area"><img alt="" class="img-fluid move-animation" src="vaibhav1.jpg"></div>
								<div class="info-area">
									<h4>Vaibhav Jadhav</h4>
									<p>TRADING SKILL</p><a href="vaibhav.php">Appoint</a>
								</div>
							</div>
							<div class="single-box text-center">
								<div class="img-area"><img alt="" class="img-fluid move-animation" src="sakshi.jpg"></div>
								<div class="info-area">
									<h4>Sakshi Shinde</h4>
									<p>WEB DEVELOPMENT</p><a href="sakshi.php">Appoint</a>
								</div>
							</div>
							<div class="single-box text-center">
								<div class="img-area"><img alt="" class="img-fluid move-animation" src="harshada.jpg"></div>
								<div class="info-area">
									<h4>Harshada Jadhav</h4>
									<p>SOFTWERE DEVELOPMENT</p><a href="harshada.php">Appoint</a>
								</div>
							</div>
                            <div class="single-box text-center">
								<div class="img-area"><img alt="" class="img-fluid move-animation" src="harsh1.jpg"></div>
								<div class="info-area">
									<h4>Harsh Jadhav</h4>
									<p>FRONT-END DEVELOPMENTT</p><a href="harsh.php">Appoint</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
    <hr class="rounded" >
	<div class="container">
        <h2>Also appoint </h2>
        <div class="blog-post">
            <div class="blog-post_img">
                <img src="pratik.jpg"
                    alt="">
            </div>
            <div class="blog-post_info">
                <div class="blog-post_date">
                    <span>Full-Stack Developer</span>
                    <span>Nov 12 2021</span>
                </div>
                <h1 class="blog-post_title">PRATIK SAWANT</h1>
                <p class="blog-post_text">
				Front-end technology, Development Languages, Database, Basic design ability, Server
                </p>
                <a href="#" class="blog-post_cta">Fix Meet</a>
            </div>
        </div>

        <div class="blog-post">
            <div class="blog-post_img">
                <img src="shubham.jpg"
                    alt="">
            </div>
            <div class="blog-post_info">
                <div class="blog-post_date">
                    <span>Front-End Developer</span>

                </div>
                <h1 class="blog-post_title">SHUBHAM GHADGE</h1>
                <p class="blog-post_text">
				implements web designs through programming languages like HTML, CSS, and JavaScript.
                </p>
                <a href="shubham.php" class="blog-post_cta">Fix Meet</a>
            </div>
        </div>
		<div class="blog-post">
            <div class="blog-post_img">
                <img src="shridhar.jpg"
                    alt="">
            </div>
            <div class="blog-post_info">
                <div class="blog-post_date">
                    <span>Back-End Developer</span>
                 
                </div>
                <h1 class="blog-post_title">SHRIDHAR AWARE</h1>
                <p class="blog-post_text">
				build and maintain the mechanisms that process data and perform actions on websites.
                </p>
                <a href="shridhar.php" class="blog-post_cta">Fix Meet</a>
            </div>
        </div>
		<div class="blog-post">
            <div class="blog-post_img">
                <img src="dipali.jpg"
                    alt="">
            </div>
            <div class="blog-post_info">
                <div class="blog-post_date">
                    <span>Communication Skills</span>
                
                </div>
                <h1 class="blog-post_title">DIPALI LAKERI</h1>
                <p class="blog-post_text">
                   best in communication..
                </p>
                <a href="dipali.php" class="blog-post_cta">Fix Meet</a>
            </div>
        </div>
		<div class="blog-post">
            <div class="blog-post_img">
                <img src="sakshi.jpg"
                    alt="">
            </div>
            <div class="blog-post_info">
                <div class="blog-post_date">
                    <span>Web Developer</span>
                </div>
                <h1 class="blog-post_title">SAKSHI SHINDE</h1>
                <p class="blog-post_text">
				JavaScript and SQL,The ability to explain technical matters clearly,A logical approach to work.
                </p>
                <a href="sakshi.php" class="blog-post_cta">Fix Meet</a>
            </div>
        </div>
		<div class="blog-post">
            <div class="blog-post_img">
                <img src="arti.jpg"
                    alt="">
            </div>
            <div class="blog-post_info">
                <div class="blog-post_date">
                    <span>Web Designer</span>
                </div>
                <h1 class="blog-post_title">ARTI SHINDE</h1>
                <p class="blog-post_text">
				Problem-solving,HTML, CSS,JavaScript,python.colour combinations...
                </p>
                <a href="arti.php" class="blog-post_cta">Fix Meet</a>
            </div>
        </div>
    </div>
	<hr class="rounded">
	
	<footer>
    <div class="footer-content">
        <h3>Appoint Me</h3>
        <p> It is a online appintment scheduling website which scedul you meetings or appointments
            awith respect to your time management...</p>
        <ul class="socials">
            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
            <li><a href="#"><i class="fa fa-youtube"></i></a></li>
            <li><a href="#"><i class="fa fa-linkedin-square"></i></a></li>
        </ul>
    </div>
    <div class="footer-bottom">
        <p>copyright &copy; <a href="home.php">AppointMe</a>  </p>
                <div class="footer-menu">
                  <ul class="f-menu">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="contact.php">Contact</a></li>
                    <li><a href="comment.php">Comment</a></li>
                  </ul>
                </div>
    </div>

</footer> 
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js">
	</script> 
	<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js">
	</script> 
	<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/js/bootstrap.min.js">
	</script> 
	<script>
         $(document).ready(function(){
      $('.btn').click(function(){
        $('.items').toggleClass("show");
        $('ul li').toggleClass("hide");
      });
    });
	       $('.team-slider').owlCarousel({
	           loop: true,            
	           nav: false,
	           autoplay: true,
	           autoplayTimeout: 5000,
	           smartSpeed: 450,
	           margin: 20,
	           responsive: {
	               0: {
	                   items: 1
	               },
	               768: {
	                   items: 2
	               },
	               991: {
	                   items: 3
	               },
	               1200: {
	                   items: 3
	               },
	               1920: {
	                   items: 3
	               }
	           }
	       });
	</script>
</body>
</html>
