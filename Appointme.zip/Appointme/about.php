<!DOCTYPE html>
<head>
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">

   <title>Appointment System</title>
   <link rel="stylesheet" href="style.css">
   <script src="https://code.jquery.com/jquery-3.4.1.js"></script>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
   <script src="https://kit.fontawesome.com/dbed6b6114.js" crossorigin="anonymous"></script>
   <style>
    @import url('https://fonts.googleapis.com/css?family=Montserrat:400,500,600,700&display=swap');
*{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Montserrat',sans-serif;
}
nav{
  background: #151515;
  padding: 5px 40px;
}
nav ul{
  list-style: none;
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: center;
}
nav ul li{
  padding: 15px 0;
  cursor: pointer;
}
nav ul li.items{
  position: relative;
  width: auto;
  margin: 0 16px;
  text-align: center;
  order: 3;
}
nav ul li.items:after{
  position: absolute;
  content: '';
  left: 0;
  bottom: 5px;
  height: 2px;
  width: 100%;
  background: #33ffff;
  opacity: 0;
  transition: all 0.2s linear;
}
nav ul li.items:hover:after{
  opacity: 1;
  bottom: 8px;
}
nav ul li.logo{
  flex: 1;
  color: white;
  font-size: 30px;
  font-weight: 600;
  cursor: default;
  user-select: none;
  font-family: 'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;

}
nav ul li a{
  color: white;
  font-size: 21px;
  text-decoration: none;
  transition: .4s;
}
nav ul li:hover a{
  color: cyan;
}
nav ul li i{
  font-size: 23px;
}
nav ul li.btn{
  display: none;
}
nav ul li.btn.hide i:before{
  content: '\f00d';
}
@media all and (max-width: 900px){
  nav{
    padding: 5px 30px;
  }
  nav ul li.items{
    width: 100%;
    display: none;
  }
  nav ul li.items.show{
    display: block;
  }
  nav ul li.btn{
    display: block;
  }
  nav ul li.items:hover{
    border-radius: 5px;
    box-shadow: inset 0 0 5px #33ffff,
                inset 0 0 10px #66ffff;
  }
  nav ul li.items:hover:after{
    opacity: 0;
  }
}
@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700&display=swap');

*{
    box-sizing: border-box;
    padding: 0;
    margin: 0;
}
body{
    font-family: 'Playfair Display', serif;
    display: grid;
    background-color: #f4f4f4;
    align-content: center;
    min-height: 100vh;
}
section{
    display: grid;
    grid-template-columns: 1fr 1fr;
    min-height: 90vh;
    width: 85vw;
    margin: 0 auto;
}

.content{
    background: #fff;
    display: flex;
    justify-content: center;
    flex-direction: column;
    align-items: center;
}
.content h2{
    text-transform: uppercase;
    font-size: 36px;
    letter-spacing: 6px;
    opacity: 0.9;
}
.content span{
    height: 0.5px;
    width: 80px;
    background: rgb(0, 0, 0);
    margin: 30px 0;
}
.content p{
    padding-bottom: 15px;
    font-weight: 300;
    opacity: 0.7;
    width: 60%;
    text-align: center;
    margin: 0 auto;
    line-height: 1.7;
}
.links{
    margin: 15px 0;
}
.links li{
    border: 0.5px solid #777;
    list-style: none;
    border-radius: 5px;
    padding: 10px 15px;
    width: 160px;
    text-align: center;
}
.links li a{
    text-transform: uppercase;
    color: #777;
    text-decoration: none;
}
.links li:hover{
    border-color: #3506a1;
}
.links li:hover a{
    color :#1412a5;
}
.vertical-line{
    height: 30px;
    width: 0.5px;
    background: rgb(110, 161, 209);
    margin: 0 auto;
}
.icons{
    display: flex;
    padding: 15px 0;
}
.icons li{
    display: block;
    padding: 5px;
    margin: 5px;
}
.icons li i{
    font-size: 26px;
    opacity: 0.8;
}
.icons li i:hover{
    color: #06d6a0;
}



@media(max-width: 992px){
    section{
        grid-template-columns: 1fr;
        width: 100%;
    }
    .image1{
        height: 100vh;
    }
    .content{
        height: 100vh;
    }
    .content h2{
        font-size: 20px;
        margin-top: 50px;
    }
    .content span{
        margin: 20px 0;
    }
    .content p{
        font-size: 14px;
    }
    .links li a{
        font-size: 14px;
    }
    .links{
        margin: 5px 0;
    }
    .links li{
        padding: 6px 10px;
    }
    .icons li i{
        font-size: 15px;
    }
}
hr.rounded {
  border-top: 8px solid rgb(7, 7, 41);
  border-radius: 5px;
  
}
*,
*::before,
*::after{
    box-sizing: border-box;
}
html{
    font-family: sans-serif;
    line-height: 1.15;
}
body{
    font-family: 'lato', sans-serif;
    color: #454545;
    font-weight: 300;
    background: #ffffff;
}
a{
    color: #333333;
    font-weight: 400;
    outline: none;
    text-decoration: none;
    transition: 0.5s;
}
a:hover,
a:focus{
    outline: none;
    text-decoration: none;
}
p{
    padding: 0;
    margin: 0 0 15px 0;
    color: #454545;
    font-weight: 300;
}
h1,
h2,
h3,
h4,
h5,
h6{
    padding: 0;
    margin: 0 0 15px 0;
    color: #333333;
    font-weight: 700;
}
img{
    width: 100%;
    height: auto;
}
.container{
    width: 100%;
    padding-right: 15px;
    padding-left: 15px;
    margin-right: auto;
    margin-left: auto;
}
.section-title{
    flex: 0 0 100%;
    max-width: 100%;
    margin-bottom: 80px;
    margin-top: 40px;
    text-align: center;
}
.section-title h1{
    display: inline-block;
    font-size: 35px;
    text-transform: uppercase;
    font-weight: 700;
    color: #000000;
    margin: 0 0 5px;
    position: relative;
}
.section-title h1::before{
    content: '';
    left: 0;
    position: absolute;
    height: 3px;
    right: 32%;
    background-color: #50c5fc;
    bottom: -5px;

}
.container .section-title h1::before{
    left: 30%;
}
.row{
    display: flex;
    flex-wrap: wrap;
    margin-right: -15px;
    margin-left: -15px;
}
.column{
    position: relative;
    width: 100%;
    padding-right: 15px;
    padding-left: 15px;
    flex: 0 0 100%;
    max-width: 100%;
}
.team{
    margin-bottom:30px ;
}
.team .team-img{
    position: relative;
    font-size: 0;
    text-align: center;
}
.team .team-img img{
    width: 160px;
    height: auto;
    border-radius: 100%;
    border: 20px solid #f3f4fa;
}

.team .team-content{
    padding: 80px 20px 20px 20px;
    margin-top: -80px;
    text-align: center;
    background: #f3f4fa;
    border-radius: 10px;
}
.team .team-content h2{
font-size: 25px;
font-weight: 400;
letter-spacing: 2px;
}
.team .team-content h3{
    font-size: 16px;
    font-weight: 300;
}
.team .team-content h4{
    font-size: 16px;
font-weight: 300;
letter-spacing: 1px;
font-style: italic;
margin-bottom: 0;
}
.team .team-content p{
    font-size: 16px;
    font-weight: 400;
    line-height: 22px;
}
.team .team-social{
    position: absolute;
    width: 100%;
    height: 100%;
    padding: 35px;
    top: 0;
    left:0;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(255, 255, 255, .6);
    transition: all .3s;
    font-size: 0;
    z-index: 1;
    opacity: 0;
}
.team:hover .team-social{
    opacity: 1;
}
.team .team-social a{
    display: inline-block;
    width: 40px;
    height: 40px;
    margin-right:5px ;
    padding: 11px 0 10px 0;
    font-size: 16px;
    font-weight: 300;
    line-height: 16px;
    text-align: center;
    color: #ffffff;
    border-radius: 10px;
    transition: all .3s;
    margin-top: 50px;
}
.team .team-social a.social-tw{
    background: #00acee;
}
.team .team-social a.social-fb{
    background: #3b5998;
}
.team .team-social a.social-li{
    background: #0e76a8;
}
.team .team-social a.social-in{
    background: #3f729b;
}
.team .team-social a.social-yt{
    background: #c4302b;
}
.team .team-social a:last-child{
    margin-right: 0;
}
.team:hover .team-social a{
    margin-top: 0;
}
.team .team-social a:hover{
    background: #222222;
}


/* Mobile Responsive */

@media (min-width: 576px){
    .container{
        max-width: 540px;
    }
    .column{
        max-width: 50%;
    }
}
@media (min-width: 768px){
    .container{
        max-width: 720px;
    }
    .column{
        max-width: 33.333333%;
    }
}
@media (min-width: 992px){
    .container{
        max-width: 960px;
    }
    .column{
        max-width: 25%;
    }
}
@media (min-width: 1200px){
    .container{
        max-width: 1140px;
    }
   
}
* {
  box-sizing: border-box;
}

.column1 {
  float: left;
  width: 33.33%;
  padding: 5px;
}

.row1::after {
  content: "";
  clear: both;
  display: table;
}

@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Fira+Sans:wght@500;600&display=swap');
*{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: "Poppins" , sans-serif;
}

::selection{
  background: #7d2ae8;
  color: #fff;
}
.accordion{
  display: flex;
  max-width: 1010px;
  width: 100%;
  align-items: center;
  justify-content: space-between;
  background: #fff;
  border-radius: 25px;
  padding: 45px 90px 45px 60px;
}
.accordion .image-box{
  height: 360px;
  width: 300px;
}
.accordion .image-box img{
  height: 100%;
  width: 100%;
  object-fit: contain;
}
.accordion .accordion-text{
  width: 60%;
}
.accordion .accordion-text .title{
  font-size: 35px;
  font-weight: 600;
  color: darkblue;
  font-family: 'Fira Sans', sans-serif;
}
.accordion .accordion-text .faq-text{
  margin-top: 25px;
  height: 263px;
  overflow-y: auto;
}
.faq-text::-webkit-scrollbar{
  display: none;
}
.accordion .accordion-text li{
  list-style: none;
  cursor: pointer;
}
.accordion-text li .question-arrow{
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.accordion-text li .question-arrow .question{
  font-size: 18px;
  font-weight: 500;
  color: #595959;
  transition: all 0.3s ease;
}
.accordion-text li .question-arrow .arrow{
  font-size: 20px;
  color: #595959;
  transition: all 0.3s ease;
}
.accordion-text li.showAnswer .question-arrow .arrow{
  transform: rotate(-180deg);
}
.accordion-text li:hover .question-arrow .question,
.accordion-text li:hover .question-arrow .arrow{
  color: #7d2ae8;
}
.accordion-text li.showAnswer .question-arrow .question,
.accordion-text li.showAnswer .question-arrow .arrow{
  color: #7d2ae8;
}
.accordion-text li .line{
  display: block;
  height: 2px;
  width: 100%;
  margin: 10px 0;
  background: rgba(0, 0, 0, 0.1);
}
.accordion-text li p{
  width: 92%;
  font-size: 15px;
  font-weight: 500;
  color: #595959;
  display: none;
}
.accordion-text li.showAnswer p{
  display: block;
}

@media (max-width: 994px) {
  body{
    padding: 40px 20px;
  }
  .accordion{
    max-width: 100%;
    padding: 45px 60px 45px 60px;
  }
  .accordion .image-box{
    height: 360px;
    width: 220px;
  }
  .accordion .accordion-text{
    width: 63%;
  }
}
@media (max-width: 820px) {
  .accordion{
    flex-direction: column;
  }
  .accordion .image-box{
    height: 360px;
    width: 300px;
    background: #7d2ae8;
    width: 100%;
    border-radius: 25px;
    padding: 30px;
  }
  .accordion .accordion-text{
    width: 100%;
    margin-top: 30px;
  }
}
@media (max-width: 538px) {
  .accordion{
    padding: 25px;
  }
  .accordion-text li p{
    width: 98%;
  }
}

footer{
    position: relative;
    bottom: 0;
    left: 0;
    right: 0;
    background: #111;
    height: auto;
    width: 100vw;

    padding-top: 0;
    color: #fff;
}
.footer-content2{
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    text-align: center;
}
.footer-content2 h4{
    font-size: 2.1rem;
    font-weight: 500;
    text-transform: capitalize;
    line-height: 3rem;
    font-family: 'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;

}
.footer-content2 p{
    max-width: 500px;
    margin: 10px auto;
    line-height: 28px;
    font-size: 14px;
    color: #cacdd2;
}
.socials{
    list-style: none;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 1rem 0 3rem 0;
}
.socials li{
    margin: 0 10px;
}
.socials a{
    text-decoration: none;
    color: #fff;
    border: 1.1px solid white;
    padding: 5px;

    border-radius: 50%;

}
.socials a i{
    font-size: 1.1rem;
    width: 20px;


    transition: color .4s ease;

}
.socials a:hover i{
    color: aqua;
}

.footer-bottom{
    background: #000;
    width: 100vw;
    padding: 20px;
padding-bottom: 40px;
    text-align: center;
}
.footer-bottom p{
float: left;
    font-size: 14px;
    word-spacing: 2px;
    text-transform: capitalize;
}
.footer-bottom p a{
  color:#44bae8;
  font-size: 16px;
  text-decoration: none;
}
.footer-bottom span{
    text-transform: uppercase;
    opacity: .4;
    font-weight: 200;
}
.footer-menu{
  float: right;

}
.footer-menu ul{
  display: flex;
}
.footer-menu ul li{
padding-right: 10px;
display: block;
}
.footer-menu ul li a{
  color: #cfd2d6;
  text-decoration: none;
}
.footer-menu ul li a:hover{
  color: #27bcda;
}

@media (max-width:500px) {
.footer-menu ul{
  display: flex;
  margin-top: 10px;
  margin-bottom: 20px;
}
}
   </style>
</head>
<body>
   <nav>
      <ul>
         <li class="logo">AppointMe</li>
         <li class="items"><a href="home.php">Home</a></li>
         <li class="items"><a href="about.php">About</a></li>
         <li class="items"><a href="contact.php">Contact</a></li>
         <li class="items"><a href="appointwith.php">Appoint With</a></li>
         <li class="items"><a href="feedback.php">Commment</a></li>
         <li class="btn"><a href="#"><i class="fas fa-bars"></i></a></li>
      </ul>
   </nav>
   <section>
    <div class = "image1">
        <!-- image here -->
        <img src="https://thumbs.dreamstime.com/b/calendar-appointment-day-circled-reminder-19147605.jpg" alt="">
     <img src="" alt="">
      </div>

    <div class = "content">
        <h2>About Us</h2>
      

        <p style="color: black;font-family:'Times New Roman', Times, serif;font-weight: bold;">An appointment booking system lets users see  availiability and srvices directly from our outreach materials.By including a link to our booking system in an email,for instance,we provide users with an easy ,no commitment way to check out our services. Appointments are opportunities to meet your prospects face to face and get a better understanding of their needs.Appointment scheduling is important as it ensures that you make Best use of your own Time.</p>

        <ul class = "links">
            <li><a href = "choose.php">Choose</a></li>

            <div class = "vertical-line"></div>

            <li><a href = "appointwith.php">Appoint With</a></li>

            <div class = "vertical-line"></div>
            
            <li><a href = "contact.php">contact</a></li>
        </ul>

        <ul class = "icons">
            <li>
                <i class = "fa fa-twitter"></i>
            </li>
            <li>
                <i class = "fa fa-facebook"></i>
            </li>
            <li>
                <i class = "fa fa-github"></i>
            </li>
            <li>
                <i class = "fa fa-pinterest"></i>
            </li>
        </ul>
    </div>
</section>
<hr class="rounded" >
<div class="container">
        <div class="section-title">
            <h1>Our Executed Team</h1>
        </div>

        <div class="row">


            <div class="column">
                <div class="team">
                    <div class="team-img">
                        <img src="pratik.jpg" alt="Team Image">
                    </div>
                    <div class="team-content">
                        <h2>Pratik Sawant</h2>
                        <h3>FULL-STACK DEVELOPER</h3>
                        <p>Front-end Languages and Frameworks.Database Management Systems.</p>
                        <h4>hipratiksawant@gmail.com</h4>
                    </div>
                    <div class="team-social">
                        <a href="https://twitter.com/PratikS2031?t=Sm1mRbVFDT0BqWL9i3qLcw&s=09" class="social-tw"> <i class="fab fa-twitter"></i></a>
                        <a href="https://www.facebook.com/profile.php?id=100063463190664" class="social-fb"> <i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="social-li"> <i class="fab fa-linkedin-in"></i></a>
                        <a href=" https://www.instagram.com/invites/contact/?i=1j4vsp3isvwiz&utm_content=mr78u2s" class="social-in"> <i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>

            <div class="column">
                <div class="team">
                    <div class="team-img">
                        <img src="prasad1.jpg" alt="Team Image">
                    </div>
                    <div class="team-content">
                        <h2>Prasad Sawant</h2>
                        <h3>FRONT-END DEVELOPER</h3>
                        <p>HTML/CSS.Responsive Design.Testing/Debugging.Web Performance</p>
                        <h4>Kcoding5@gmail.com</h4>
                    </div>
                    <div class="team-social">
                        <a href="#" class="social-tw"> <i class="fab fa-twitter"></i></a>
                        <a href="#" class="social-fb"> <i class="fab fa-facebook-f"></i></a>
                        <a href=" https://www.linkedin.com/in/prasad-sawant-874095214" class="social-li"> <i class="fab fa-linkedin-in"></i></a>
                        <a href="#" class="social-in"> <i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>

            <div class="column">
                <div class="team">
                    <div class="team-img">
                        <img src="priti.jpg" alt="Team Image">
                    </div>
                    <div class="team-content">
                        <h2>Priti Gawade</h2>
                        <h3>DESIGNER</h3>
                        <p>Color Theory.Software for design.Responsive design.Typography.</p>
                        <h4>pritigawade002@gmail.com</h4>
                    </div>
                    <div class="team-social">
                        <a href="https://twitter.com/gawade28_priti?t=crMBYD-0V7i8HdlbFkIeSg&s=09" class="social-tw"> <i class="fab fa-twitter"></i></a>
                        <a href="https://www.facebook.com/priti.gawade.357" class="social-fb"> <i class="fab fa-facebook-f"></i></a>
                        <a href="https://www.linkedin.com/in/priti-gawade-046a74200" class="social-li"> <i class="fab fa-linkedin-in"></i></a>
                        <a href="#" class="social-in"> <i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>

            <div class="column">
                <div class="team">
                    <div class="team-img">
                        <img src="mrunal.jpg" alt="Team Image">
                    </div>
                    <div class="team-content">
                        <h2>Mrunal Bhope</h2>
                        <h3>PRESENTER</h3>
                        <p>web presentation.Report about web. Set Goals and Vision of web</p>
                        <h4>mrunalbhope200@gmail.com</h4>
                    </div>
                    <div class="team-social">
                        <a href="#" class="social-tw"> <i class="fab fa-twitter"></i></a>
                        <a href="#" class="social-fb"> <i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="social-li"> <i class="fab fa-linkedin-in"></i></a>
                        <a href="#" class="social-in"> <i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>

        </div>

    </div>
  <hr class="rounded" >
  
  <div class="row1">
    <div class="column1">
      <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxAQEhAQDxAVFRUVFRUWEBAQFRUQFRAQFRUWFhUVFRcYHSggGBolHRUVITEiJSkrLi4uFx8zODMsNygtLisBCgoKDg0OGhAQGy0lHyUtLSstKy0tLS0tLS8tLS0tLS0tLS0tLS0tLSstLS0tKy0tLS0tKy0tLS0tLS0tLS0tLf/AABEIAJ8BPgMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAADAAECBAYFBwj/xABBEAACAQIEAwYDBgQFAQkAAAABAgADEQQSITEFQVEGEyJhcZEygaEHQlKxwdEUI2LwcoKS0uGiJDM0Q1Njc5Oy/8QAGwEAAQUBAQAAAAAAAAAAAAAAAQACAwQFBgf/xAA0EQACAQIEAwUHAwUBAAAAAAAAAQIDEQQSITFBUXEFE2Gx8CKBkaHB0fEyQuEUIzNScmL/2gAMAwEAAhEDEQA/AId4Iu8EnlHSMVHScfoek6CVrxma0alGqbiK2oba2Jd4Iu8EfKOkfKOkGgNCPeCLvBJZR0j5R0i0FdEe8El3giyDpJZB0i0BdDK4MkTaDUeIydTaBga1F3gjioIqaiw0hAg6CCyA2iHeCS7wSWQdI4QdINBl0Q7wR+9ElkHQRZB0EGgroiKoh1leqLFZYWBjZWsPHjSYgGMcR4wjwDRR4wjiIaOI5iigADNQDSIVRIqPEYXIOkWg52RHvRH7wSQQdBFkHQRaDboXeiLvRHyDoJLIOgg0BdERVEkrX2iyDoJGhsYNLAdrE2YDeN3oka3KEyDpFwFoR7wR+9EllHSLKOkQNDgxNFGMtGkRpRqm4j0o1TcQ8R/ELEI8UAwUUUUQCQiiElEAEvxGSqbSK/EZOptG8QvdEqWwhFg6WwhBEyN7kpKRko0YMY8Yx4GIDV3WHEFW3WGET2DLZDiSjLJRpExCSkRIVayJq7Ko6sQv5xAYSSEFQqo/wOrc/CwbT5Q1omrOzBcURiERgGgk+IyxK6/EYaJhkSiEQjwDRCIRo4iYh4OhtCQdHaDgLgxVuUNA1eUPEB7IUaKKAacCM0lItLZqEaUVTcRU9o1TcQ8R/ENFFFGkYo8aOIhDxxGkogMEvxGTqbSK/EZKptA9xPdE6WwhBB0thCCIY9x5IRCIRowciKKKNYAVXcQwgqu4hwImxPZCWSjCPAMAVna600+Jr62vlUWu1uZ1AA6n1m87MdlqWGValSmGrsAXZz3hU9Mx3t19rCY7s+oOPQaf+Re52AaoQbc7tp8vKepYqutNS7myjc/QAAakk2AA1JM2+yaEJJzkttvhf1/Jg9r15xtCLte/2/PMqJhMPXpUxlFRAq927EswGUZWVz4g1iDmvfWZzHcFPwkWfIXS1v5ii2dGsAC65hqAMwO1wTNJwKi1PDYZHFmWlTDqd1YIoINulrSPEb95htBpVGU31LGnUVhltsFJO/LymxVowrRyzX8dPXUxqNadGWaD/nr66HnTLY2jGWuJIBUcLtmNvcysZxkllbR2UZZkmBX4jDCCX4jCMYGOluIPJiBhKbQCaJx4orQDBSFHaTkKG0XAK2YqvKFgqvKGgGvZDRSVorRAM+YPrHJ1ils1UNT2jVOUentGqcof3Dv3BVMeDpc4SBjHuIkAEk2A1JOgA85wMX2soqbU1Z/6vhX5E6/SVe2ePIy4dToRmqeevhX6E+0ys0cNhIzjnnx2RjYzHyhNwp8N2a1O2S/eoG39NQH8wJ2sBxqhWVmVrZRd1bRlHW3Mek84jo5U3H9jpJp4Gk17Oj9cytT7Rqxft6r1yNjiePNmPdKAOrC5P7S1geOZvDVsDycaD59PWZy8kDInh6bVrFxYiopXbN3haquLqwNtDY3sYcTEYPFPSYMLg6HLtmU6jTmD1m5EoV6Xdst06udXEI4jRxIBwohFBYqoFSoxNgFYk9LAm8FrivYw3H+0tWpUZKLFKakgFdGe25vyHS0BgOCcSq0WxVClWamL3qI+py/EQubO1tdQDsZX7L8Cq4+umHpaXGao52p0gQGfzOoAHMkT6J4bgqeHp06NFcqU1CoOgHXqed50kKcKccqRzNStObzNnkXY7jTV1alVa7qLqx3entr1INtfMTTTEcIolOKYlFGULWxIy7WQO9h6fDNtMTG04wqtR46mzhKjnSTYHvGpVExCX8Ns9hcgA5lYDnlN9OjHyE9Q4LxNMXSSoMt7AsoOcK2+h5joZ5sshRpmm3eUXek34qTFbk7kr8JJ62kmCxrw71V09/v63IMdgViFo7NbevHzPXEcEAgggi4I1BB5gzM8Q4uDkq+Hwqe5AOYPXYFWqKbC9NAWAb7xY9ATlmxtZlVKlZ3UCwRsqplAsAUQKrDyIMhVrMxJY3J3J1Jl6v2vFxtSTvzfDz15fUz6HZElJOq1bkuPlpzEx1MiYhObx7iZw1NXChizBQDoBoTf6TDjByajE3G7asur8Rg6uLphspqKD+EsAfaYfG8cxFW93yg/dp+H67/Wc0iXoYFv9Tt0I5VlfRHp8kJlOzHGdRQqt/8AEx//AAT+Xt0i432xWi5p0UFQqbO5NlBG4FtSf71lf+lqOpkSuOlXhGOZuxsAZImZHDdusP3YNRKgcbogDg+asSBb1tGXt9h760KoHXwH6Zo14Ov/AKMh/qKX+yNZGobSrw3idHEpnouGA+IbMp6MDqJbobSBxcbpqzJ0043Qq3KFWDq8pOnGgexMSVpESUAwy1TeOrRnjS9wNq2hOltGqco9LaNU5QfuB+4lS5yZeDRrRiYgWuYrtZ/4l/8ADTt/pE4863alr4l/IIP+gH9ZyZvUP8Uei8jksV/nn/0/MU6HZykj4vCJUTOjV6SumviQuAw08jD9l+z1biNdaFEWGhq1T8NGnfVj1O9hzPlcj1qp9mmCoVcNXoFqa0RVOIZ6tQtUBpMqvcmykE3NrC3KTpcSrOVtDPdluw6Y3DPXNVlLM4oZcpQhSVBe4uQSDsRM5wrs/isVrQosVJylzZUVudyel9bT03gxw/DMDVdcwoq7mirHxVBoi2vzqMuYcvHfadjs9iqdbD0q1GmKa1AXyAAWcsc+25zX15yu4K9i3HFTs5W3engUe1XDaJoJUempqUsiUntqvUDy02mUDmaHtqz5qQLHIUvl5ZwTc+tiJnZlY2Waq1y0+v1Njs6mo4dO976/S3yDIbyYgqUOBKRZkRMocdpF8PXUbmm1vkL2+k6JE4vH+JhKVZUuWysLjZSRbfqI+mm5K3NeYydsr6PyM79nfHqeBxgqVtKdRGpO/wD6eZkYOfIFAD5EnlPdcZj6WHpPiKzhaaLmZ9xbla25OgAG5InzZR4bVqAZVIB0zHYA8/Se/dp1oVeH4mn3iZGokUmLAguBena2/iC7To80W9zmp05aNp6+G/Q8t4DxD+J4hicSVt3oqMFOuVSyZQfMAATYzG9nKa4a7spLsLaEAKt728zoJqcHjkq6C4P4T+nWYWMeeq5LY3cPSdOmkyyI8kBFaUya5GSjR4gCEJT4NTxt6NUkLbNdbZgRoCt+eshCcHwjti0cVGUd2y+HISpFzoHU/FfW1vgG/KbDJOtG/MgxEnGm3E877R8IODxD4ctny5Sr2y5lYXGnI8vlOZPTu03Y2ri8dRdqzd01MrUqBUzo6ZiBYLaxuutuR8pjO1vZ98BW7u5amwvSqEWzD7wP9QP0IPObso2KVKspJLjYz9Y2BPO2nrObOpVW4t1099IXifZ2vRpLV7ssoZ6VVlBIWqKjZSegZMhEdCaTUXu/oRYiLevBfc40UtVuG4hE7x8PVVNP5j0nVNdvERaVZMVSzwziFTDVFq0zqNxydeanyM9f4fXWoi1F+FgGX0IBE8Xnp/YOvnwiA7ozJ8gbj6ETK7UprIp+NvsXsFNpuHvO9V5SaSNXlJKZimjwJFpIGDMdWgG2My8dReM8LS2EvcDYbshqYjVBtCyQEaNvqV7S/gOFVKtifCv4jpf06zpcP4Ts1X5J0/xftOsJRr43LpT+P25+XUo18bbSnvz9fgzWN+zTC4lndMTVpVGIIzBa1PlcZfC1/wDNIYb7GaYP83HOw6U6S0z7szTVo87mAxeYAHfl5/8AM1Oye1O8aoVt9ovn4Px5Pjs9dXzuIhKPtJguA8Dw+BpCjhqYRd2O7VG/E7HVj/YkO0fGFwdEVWAa7ooQ/eubvbzyA/O0H2g7R0MFkFUMzOCVSkATYczciwv+vSeZ9peP1MbUzkZUXSlTvfKDuSebH9ps4iuoJpfqHYLBSrSUpr2d+vQ0n2qVFalTw9LMzl6dZAqlu8pEOoAI3NyDbymM7M4gVadXD18TWCKmbD0aLlVNQsN/S97eZO81PCu1VKo2Ap4igf8As7IqV0fWwCqMyldR8JOt/D8jHtVRQcQxRVFUnJcqACfApJPmSdTK9arHI5xfFJeF1+S7h6EozjRnG3Fu6d7SS033VvFXfMpFy2rEk9WJJPzMkJBJNZjm6wlOWVEroIapVKqzZSbC5tc+Vz0HnElcgqFTiuKyDKvxHn+EdfWcE0r6EeoPOdHune7kE3Ns1tM3T18o4wjajKdDY2F9ZZhBRViLNY53dRxT8p1BgW/CfYxxgG/CfYx+QHeHLFKFo3UhhuDcTo/wLfhPsY7YBwAcp120PI2icRKpqdemQwDDYi4+cREXDMPUFMF0IW/gY6ZhztDMkpyg4uwzMr6ASJGEKxiJEx6ZGGwlQo6MDazDXy5/S8DFAnZ3QGrqxt+9T8Se4lXivC6OKpmlXQOp1F9CrfiUjUHzEx9JbvYc9PebCmxWmqlrkDVutv7M1F2pBZnUVrK+++yt11VjIxGF7nLaV2zJp2BwdN8ytUYg3TvGUqGGo0VRces1PZ092HouLMTmU8nFgDY+VpCEptYg9DceomBR7YqxxPfT1XLkvD1qCbcqbg9b+Za7RCmcJi+9AKdxVzg/hyNefL67C89x+17tAKODGHpnx4k5TytRWxqH53Vf8xnh87ZTjOKlBprmndcilSTS1FPQPszqDusQl9RUDW6BkAv/ANB9p5/OhwHi74SqKqajaomwdOY8j0MrYui61JxW/As0ZqE02ev1RtHAguGcQpYmmKtFsynfqp5qw5GW5zLTTs9zXUk1oCtFaGEeNFmMk0LT2ECWhqewl57GzLYnO5wfA5QKjDU/CPwjr6zmcOod5UVTtu3oP7t85qJn42s4rIuO/rxM3GVbLIvf68SSLeE7jziGkkrTJbZlNvgBZCN5JKhEshcwInJ4nVKUarKbFUcg6GxA03jo+1oGLzaGV7bI/wDEl3csHUMl/uqNMnyP5zPiFxGIeoxaoxY9WN/l5CDnUwU8qzu74vma9KGSCjyCUjZlPQg+xmg4txMV8ViKosVaocpFvFTHhU+wBmdmk7J4KliGei4IJGZHFroybi3MG/0EdZzWRcX81e3mMr5Y/wBx8Fb3NpvyByaqZ0ONcPOGcILlSLoxOpAte/nf9JTRpDKMoycWtSxCqpxU47MlSUzZcHwHdp4h4m1f/bM9wdA1RQRtc+w0muoHlL2DhrmZk9o1m/7a6v6FTi2EpUqFOlTQDPVNSw5MFym3TcTvdn6OShTUix8RI8y7H9YLH5FKjQZFABPL0+kvcPcNTUjz/MzVpU7Vm/C3l9TDr1pToJPne799vkWoop4127bGtjqwp4/E0lGRUpUaj01Ud2vJWFySSbnrJq+IhRjmm9CLCYOpipuFJapX910vqeyxTldmmqHC4fvnLv3a56jaFzb4jbmZ1ZNGWZJorzg4ScXutDhcRoB86nqbHoeRmWr0CpIO4mtrXDPf8Rt5C8z+H4DXxDV2fFsLC1PLSRQjk3B1vmAAtbfXeZOJw3fNW0f5NfDVlSi8z005/KyOSywTLCthq1D+XiDmcE+O2XMt9DpvAPW8piVKbjJrkbUHmV1sK0VoPvh0ks8haaJbMjSplnCjckD085qZxuEa1PQE/p+s7UysdK81HkvP8FHFzvJR5IaOI0UolQ80+2Oi2bB1Pu2qpfkHujAfMA/6TMVT4LWKNVYBFVSxNTQkAX0Ua+9p7D2vqoyJRZQxzB/EL5Mp8JHQ3v8AK/WZXFUBUR0OzKVJ9RadX2bi5wwsIWta+vNX5fEuYbAqpHPL3L147Hm8ULjMK9J2puLEexHIjygp0Sd1dGW007PctcM4nWwz95QcqeY3Vx0ZdiP7Fp6z2d4sMXQWsBY6rUXfK43HpsR5GeOT0P7Lwe5xHTvBb1yC/wCkzO06UXS7y2q8izhZtSy8DaxR4pg3L5kFF4dBYQKbw4l5s25HY7OprUboLe+v6TtruJy+AL4Cer/kB+86YmJinerL4GJineq/XAPGjxpUKhYozMdscTkosg3dsv8AlBzH8gPnNJRM4HazA97Se3xIS48wL3Hsb/ISXCZVXTltdD8PZVVc8/MkDNNwDsVWxVPvWqCkp/7sspc1P6rXFl8+cNX+zzFofA9Fx/iZD7FbfWdesPUaukX5YyhGbi5K6MsBeXMIv/HI3HSaHCdgcWxGdqSDmSxc/IKLfWaThfYnD0rd67VT5+Bb+g1+sCwdWWlrdSKr2hQgv1X6erfMq9m6H8crUcQGburFHB8Vm0KsTvt+XSd0dkMOOVT/AFD9p28BRSkuVFCjooAEhxTEMtGoaZKsF0YAG3nY6TSjhacad6vtNLV25ddTCnj67qWpNxT4X08XpzepzcN2ao02DKHuP6r+XSX6XDQGVrvob2uLaddJnMLXxtRhbFuSdgKdH/ZaaylVIQBrlrak2FzbfTzjMHXw1dvu4tW5qyvy6+HihmIliE/bld7cfqkU63DqbuzsXuT129JfwNMKiquwvb3MrEwtE2AAJ+kuQUVK6RBUc5Rs3sXJVq4Ok5zPSRj+JlVjb1Ij5z+I/T9ou8PU/T9pK2nuQqMk7phwOQkpW7w9T9P2iznqfpDnQMjK9WgCzG/MzL43jTYao/dsCMxurahv2PmJpzufWAfC0mN2p0yepRT+kqVIt/pdmXaU4x/WrrkR7qljaNN2W2ZQy66rccjzE4tTglO5GVtDY6maIAAWAsNgBpYeUrExlalCdnJJvmPoVp07qLaXBX2OI/CsIPiWp5+IfqIjgcHyWqfmP2nTxagjUf3cSre2wtOa7Txbw1bu4Ri9E9Yrx+xdhXqSWsn8SvQwdJCWRSNLatfT28oaKMZz9WrKrLNK1/BJfJWE227seNI5pNRfaRAMbxxi1ep5EgegsJR7uXuIDNVqn/3H9s5gMtgZ00NKcV4LyOgi8sUvBHNxeFp1LCoitbbOAbTgdo+D01Q1qShSts6jQMpNrgcjrNKZVx+CWuvduWAuCcpAvbrpLVGq6ck76fToDEUY1ack0m/r13PPcpte2lyL8rixI+o956P9mNS+GrL+GsbfNKZmZ7U4VaYwuHoofvGw1Lu5VR6nS3tN/wBl+E/wmHSkbFz4qpG2drXA8gAB8pN2hXjPDx8Xp0V1f1zsYlKk4VXHlv1Z2BFFFMQuGREmH8oskbLtL90zc0ZqOBj+Sp6lj+n6S/K/D0y0qY/oH11/WWJgVXmm34vzOfqu9ST8WEQ6SUGhhRIGQvQnTEWOpCwPXQ+YtJJCMuZSLX6esjvZ3Ib2kmNhuKMtgwBA0FvDYeVtJ0qfEqR+9bysZwjhnH3T+clTw7HfT1m3R7bxNJWclJf+tX8U0/i2CdCk9duhoBiaZ++sd6ttpxO5UdfWdKnUzC/vNvs7tf8Aq5OEkotbeK4/D+StOjGOqLVKudj7xuIMO7q3IF0e19NbGwgRLTAHQi/rrNhNyi0QtKMkzOcFxPdurEXGxA85pS0EtFBsqj0AEnKmBws8NGUHK6butLW58XvZdB1aaqSzJWFJgyEeXkQtE80WaDjxXFYnmizSEUIrCMaKKAIpFqYMJaK0VhXKlfDZgADb1gDw0/iHtOllkZQxHZmGrzz1I3e27W3Rkkaslojmnh7dR7RPgTbU2Pvf5dZ0oOsl9pAuxsJFNKL14Xf5Xua4rZjlWlfVlahw9NyS30lxAFGgA9NJWAYbAxv4k7WlyhRo0F/bio9Fr729X7wSUp8bmKrcHxCsSaZNydVsw19JQx+EqU1JemyjqVIFz5z0OZrtvirU6dIfeOY+i+EfU/SUK2FhCLnd6G3hsbOpVjBpa9epjYljSSbyizZDUOHI+Io123phgBvq1rH5eL38powROLhDYj5TtZZUqttq/D8/UzqsUpNriK4izRZY+WREehmYqaZnRRzNveBDGdXs9hs1QufujT/FoB+su1Jd3By5GvVl3cHLkaMC2keKKc+YAodDeAhaJ1tA9hstg6yd5AR5CyBks5jXlingydSbfUQiYC/3vpNKHZGNmk1TevNpfJu6I+8guJSvLOGpPfRd+k6NCgqbDXrCTewPYToTjVqT9pa2S0+L3+CIJ109EgNKkdz9NYfKYgZLMZ0KSRXk2xshj93HzwtGoL2I9DHJIY20gWQRd30l4AQL02vcOR0FgR6R/djFUK/ct0iFBun5Q9SmNfEwO4IJ0+W0jnW1yfUgEXPpBkQc79IE1Fh/xrBy13qDrB1HU/d+e0a4rgxyk+KAwOMoCoj02JAZSCVJVgD0I1B84e0UbYenZ3MdV7I1iTlx9UDkGQMQPM3F/aBbsbWO+Pqf/WP902uWLLIu5hyLSxlZfu+S+xiKfYmsrBl4hVDA3BCC4P8AqmzwiMqIrvnYKAz2C52A1aw0F+ghMseOjBR2IqtadW2d3t0FETFKjHXWGTsMjG5bga6jfnId6eshGOd0OjCzFMn2z4dUJGIFyoAVhb4Bc2PoSZrJYr0VdGpsLqylGHkRaRVKKqwcfVyzRxLw9RT+PTiePxxCYugabvTbdGIPqptICYTOs6F3DHSdum1wD5TgYYmdbh9W91PqPSVKiKVeOpcijSQkRWP/2Q==" alt="Snow" style="width:100%">
    </div>
    <div class="column1">
      <img src="  https://www.insperity.com/wp-content/uploads/2016/08/Skip-level-Meetings-How-to-Get-Truly-Honest-Feedback-from-Employees-640x302.png" alt="Forest" style="width:100%">
    </div>
    <div class="column1">
      <img src="https://www.booking-wp-plugin.com/wp-content/uploads/2019/10/3-reasons-to-use-booking-plugin-for-legal-services.jpg" alt="Mountains" style="width:100%">
    </div>
  </div>
  <hr class="rounded" >
  <div class="accordion">
    <div class="image-box">
    <img src="question.jpg" alt="Accordion Image">
    </div>
    <div class="accordion-text">
      <div class="title">FAQ</div>
    <ul class="faq-text">
      <li>
        <div class="question-arrow">
          <span class="question">What is the use of appointment system?</span>
          <i class="bx bxs-chevron-down arrow"></i>
        </div>
        <p>An appointment scheduling solution, also known as appointment booking system or appointment management software, is a solution that makes it easy for service providers to manage appointments. The tools within an appointment management solution can include: Internet booking.</p>
        <span class="line"></span>
      </li>
      <li>
        <div class="question-arrow">
          <span class="question">Why appointment system is important?</span>
          <i class="bx bxs-chevron-down arrow"></i>
        </div>
        <p>In summary, appointment scheduling is important as it ensures that you make the best use of your time, it will also illustrate to others that you value your own time.</p>
        <span class="line"></span>
      </li>
      <li>
        <div class="question-arrow">
          <span class="question">What is an appointment scheduler?</span>
          <i class="bx bxs-chevron-down arrow"></i>
        </div>
        <p>A Scheduler, or Appointment Scheduler, coordinates appointments for employees, customers or patients. Their main duties include planning weekly employee schedules, determining appointment lengths and making phone calls to patients or customers regarding their appointment or meeting times.</p>
        <span class="line"></span>
      </li>
      <li>
        <div class="question-arrow">
          <span class="question">What are scheduling skills?</span>
          <i class="bx bxs-chevron-down arrow"></i>
        </div>
        <p>The ability to overcome such complex and frustrating situations by planning your activities such that you are able to complete all your projects and goals according to your priorities as well as within the available time limit is referred to as the scheduling skills..</p>
        <span class="line"></span>
      </li>
      <li>
        <div class="question-arrow">
          <span class="question">What are scheduling policies?</span>
          <i class="bx bxs-chevron-down arrow"></i>
        </div>
        <p>A scheduling policy is a set of rules and objectives that guides the schedule optimizer in its decisions. Use scheduling policies to promote or de-emphasize factors like business priorities, travel time, and customer preferences. Whenever you optimize your team's schedule, you can select a guiding scheduling policy.</p>
        <span class="line"></span>
      </li>
    </ul>
    </div>
  </div>

  <footer>
    <div class="footer-content2">
        <h4>Appoint Me</h4>
        <p1> It is a online appintment scheduling website which schedul you meetings or appointments
            awith respect to your time management...</p1>
        <ul class="socials">
            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
            <li><a href="#"><i class="fa fa-youtube"></i></a></li>
            <li><a href="#"><i class="fa fa-linkedin-square"></i></a></li>
        </ul>
    </div>
    <div class="footer-bottom">
        <p>copyright &copy; <a href="home.php">AppointMe</a>  </p>
                <div class="footer-menu">
                  <ul class="f-menu">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="contact.php">Contact</a></li>
                    <li><a href="comment.php">Comment</a></li>
                  </ul>
                </div>
    </div>

</footer>
   <script>
      $(document).ready(function(){
        $('.btn').click(function(){
          $('.items').toggleClass("show");
          $('ul li').toggleClass("hide");
        });
      });
      let li = document.querySelectorAll(".faq-text li");
    for (var i = 0; i < li.length; i++) {
      li[i].addEventListener("click", (e)=>{
        let clickedLi;
        if(e.target.classList.contains("question-arrow")){
          clickedLi = e.target.parentElement;
        }else{
          clickedLi = e.target.parentElement.parentElement;
        }
       clickedLi.classList.toggle("showAnswer");
      });
    }
   </script>
</body>
</html>